# Análisis de Finanzas y Economía

Este repositorio contiene un conjunto de scripts, datos y notebooks para el análisis de series financieras y modelos econométricos, enfocados en:

- Modelos de política de dividendos (Modelo de Lintner)
- Panel de datos de América Latina
- Modelos ARIMA y GARCH para series temporales
- Visualización y exploración de indicadores macroeconómicos

## Estructura

- `data/`: Datos brutos y procesados
- `notebooks/`: Jupyter Notebooks con análisis paso a paso
- `scripts/`: Funciones reutilizables
- `reports/`: Resultados y presentaciones

## Requisitos

Instala las dependencias con:

```bash
pip install -r requirements.txt
```

o

```bash
conda env create -f environment.yml
```

## Licencia

Distribuido bajo la licencia MIT. Ver `LICENSE` para más información.
